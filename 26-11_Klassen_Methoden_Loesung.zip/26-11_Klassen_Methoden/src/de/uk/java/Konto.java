package de.uk.java;

public class Konto {
	
	// Instanzvariablen initiieren
	private int id;
	private String name;
	private int kontostand;
	
	// Konstruktor nimmt id und name an
	public Konto (int id, String name) {
		this(id, name, 0);
	}
	
	// Konstruktor nimmt id, name und kontostand an
	public Konto (int id, String name, int kontostand) {
		this.id = id;
		this.name = name;
		this.kontostand = kontostand;
	}
	
	// getId
	public int getId() {
		return id;
	}

	// getName
	public String getName() {
		return name;
	}
	
	// getKontostand
	public int getKontostand() {
		return kontostand;
	}
	
	public void einzahlen(int menge) {
		kontostand += menge;
		System.out.println(menge + " Euro wurde(n) auf das Konto eingezahlt. Neuer Kontostand: " + kontostand);
	}
	
	// Methode auszahlen - eine Methode die eine bestimmte Menge von dem Konto abzieht, sofern genug Geld auf dem Konto ist
	public void auszahlen(int menge) {
		if (menge <= kontostand) {
			kontostand -= menge;
			System.out.println(menge + " Euro wurde(n) vom Konto abgehoben. Neuer Kontostand: " + kontostand);
		} else {
			System.out.println("Es ist nicht genug Geld auf dem Konto");
		}
	}
	
}
